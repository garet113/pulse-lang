# Pulse Studio

Real-time reactive programming UI.

## Run locally
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload

Open frontend/index.html

## Live demo
Use /docs with GitHub Pages
