function rand(v){return Math.max(0,Math.min(1,v+(Math.random()-0.5)*0.1))}
let s={comfort:0.5,mood:0.4,arousal:0.3};

const ctx=document.getElementById("chart").getContext("2d");
const chart=new Chart(ctx,{type:"line",data:{labels:[],datasets:[{label:"Comfort",data:[]},{label:"Mood",data:[]},{label:"Arousal",data:[]}]}});

function update(){
 s.comfort=rand(s.comfort);
 s.mood=rand(s.mood);
 s.arousal=rand(s.arousal);
 const t=new Date().toLocaleTimeString();
 chart.data.labels.push(t);
 chart.data.datasets[0].data.push(s.comfort);
 chart.data.datasets[1].data.push(s.mood);
 chart.data.datasets[2].data.push(s.arousal);
 if(chart.data.labels.length>20){
  chart.data.labels.shift();
  chart.data.datasets.forEach(x=>x.data.shift());
 }
 chart.update();
}
setInterval(update,500);
